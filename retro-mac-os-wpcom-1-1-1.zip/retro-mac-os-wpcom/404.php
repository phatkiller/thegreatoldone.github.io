<?php
/**
 * @package WordPress
 * @subpackage Retro MacOS
 */
get_header(); ?>

	<div id="content" class="narrowcolumn">
		<h2 class="center"><?php _e( 'Not Found', 'retro' ); ?></h2>
	</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>