<?php
/**
 * @package WordPress
 * @subpackage Retro MacOS
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) )
	$content_width = 438; /* pixels */

/**
 * Set a default theme color array for WP.com.
 */
$themecolors = array(
	'bg' => 'ffffff',
	'border' => '000000',
	'text' => '444444',
	'link' => '000000',
	'url' => '000000',
);

if ( ! function_exists( 'retro_setup' ) ):
/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function retro_setup() {
	/**
	 * Add default posts and comments RSS feed links to head
	 */
	add_theme_support( 'automatic-feed-links' );

	/**
	 * This theme uses wp_nav_menu() in one location.
	 */
	register_nav_menus( array(
		'primary' => __( 'Desktop Menu', 'retro' ),
	) );

	/**
	 * Add support for the Aside and Gallery Post Formats
	 */
	add_theme_support( 'post-formats', array( 'aside' ) );

	/**
	 * Add support for custom backgrounds
	 */
	add_theme_support( 'custom-background' );

	/**
	 * Add support for custom headers
	 */
	add_theme_support( 'custom-header', apply_filters( 'retro_custom_header_args', array(
		'default-image'       => '',
		'default-text-color'  => '',
		'header-text'         => false,
		'width'               => 758,
		'height'              => 180,
		'wp-head-callback'    => '',
		'admin-head-callback' => 'retro_admin_header_style',
	) ) );

	add_theme_support( 'print-style' );

	load_theme_textdomain( 'retro', get_template_directory() . '/languages' );
}
endif; // retro_setup

/**
 * Tell WordPress to run retro_setup() when the 'after_setup_theme' hook is run.
 */
add_action( 'after_setup_theme', 'retro_setup' );

/**
 * Styles the header image displayed on the Appearance > Header admin panel.
 */
function retro_admin_header_style() {
?>
	<style type="text/css">
		#headimg {
			width: <?php echo HEADER_IMAGE_WIDTH; ?>px;
			height: <?php echo HEADER_IMAGE_HEIGHT; ?>px;
		}
		#heading {
			display: none;
		}
	</style>
<?php
}

/**
 * Register widgetized area and update sidebar with default widgets
 */
function retro_widgets_init() {

	register_sidebar( array(
		'name' => __( 'Footer Area One', 'retro' ),
		'id' => 'sidebar-1',
		'description' => __( 'An optional widget area for your site footer', 'retro' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array(
		'name' => __( 'Footer Area Two', 'retro' ),
		'id' => 'sidebar-2',
		'description' => __( 'An optional widget area for your site footer', 'retro' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
}
add_action( 'init', 'retro_widgets_init' );

/**
 * Count the number of footer sidebars to enable dynamic classes for the footer
 */
function retro_footer_sidebar_class() {
	$count = 0;

	if ( is_active_sidebar( 'sidebar-1' ) )
		$count++;

	if ( is_active_sidebar( 'sidebar-2' ) )
		$count++;

	$class = '';

	switch ( $count ) {
		case '1':
			$class = 'one';
			break;
		case '2':
			$class = 'two';
			break;
	}

	if ( $class )
		echo 'class="' . $class . '"';
}

/**
 * Enqueue scripts and styles
 */
function retro_scripts() {
	wp_enqueue_style( 'retro', get_stylesheet_uri() );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );
}
add_action( 'wp_enqueue_scripts', 'retro_scripts' );

/**
 * Filters wp_title to print a neat <title> tag based on what is being viewed.
 *
 * @since Retro MacOS 1.1
 */
function retro_wp_title( $title, $sep ) {
	global $page, $paged;

	if ( is_feed() )
		return $title;

	// Add the blog name
	$title .= get_bloginfo( 'name' );

	// Add the blog description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		$title .= " $sep $site_description";

	// Add a page number if necessary:
	if ( $paged >= 2 || $page >= 2 )
		$title .= " $sep " . sprintf( __( 'Page %s', 'retro' ), max( $paged, $page ) );

	return $title;
}
add_filter( 'wp_title', 'retro_wp_title', 10, 2 );


// updater for WordPress.com themes
if ( is_admin() )
	include dirname( __FILE__ ) . '/inc/updater.php';
